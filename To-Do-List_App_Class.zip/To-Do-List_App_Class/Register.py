from tkinter import *
from tkinter import messagebox
import pymysql


class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password


class DatabaseHandler:
    def __init__(self):
        try:
            self.con = pymysql.connect(host='localhost', user='root', password='12345')
            self.mycursor = self.con.cursor()
        except Exception as e:
            messagebox.showerror('Error', f'Could not connect to the server. {e}')

    def initialize_database(self):
        try:
            self.mycursor.execute('create database if not exists registration')
            self.mycursor.execute('use registration')
            self.mycursor.execute(
                'create table if not exists student(id int auto_increment primary key not null,'
                ' username varchar(100), password varchar(20))')
        except Exception as e:
            messagebox.showerror('Error', f'Could not initialize the database. {e}')

    def check_username_existence(self, username):
        query = 'select * from student where username=%s'
        self.mycursor.execute(query, (username,))
        return self.mycursor.fetchone() is not None

    def insert_user(self, username, password):
        query = 'insert into student(username, password) values(%s, %s)'
        self.mycursor.execute(query, (username, password))
        self.con.commit()

    def close_connection(self):
        self.con.close()


class RegistrationForm:
    def __init__(self, master):
        self.master = master
        self.master.geometry("500x500")
        self.master.resizable(False, False)
        self.master.title("Registration Form")
        self.master['bg'] = "#909af5"

        self.create_widgets()

    def create_widgets(self):
        self.lb1 = Label(self.master, text="To Do APP", width=10, bg="#909af5",
                         font=("arial", 20, 'bold'))
        self.lb1.place(x=150, y=30)

        self.lb2 = Label(self.master, text="Register", width=10, bg="#909af5",
                         font=("arial", 16, 'bold'))
        self.lb2.place(x=170, y=100)

        self.lb3 = Label(self.master, text="User Name", width=10, bg="#909af5",
                         font=("arial", 12))
        self.lb3.place(x=19, y=160)
        self.en3 = Entry(self.master)
        self.en3.place(x=200, y=160)

        self.lb4 = Label(self.master, text="Enter Password", width=13, bg="#909af5",
                         font=("arial", 12))
        self.lb4.place(x=19, y=220)
        self.en4 = Entry(self.master, show='*')
        self.en4.place(x=200, y=220)

        self.lb5 = Label(self.master, text="Conform Password", width=15, bg="#909af5",
                         font=("arial", 12))
        self.lb5.place(x=21, y=280)
        self.en5 = Entry(self.master, show='*')
        self.en5.place(x=200, y=280)

        Button(self.master, text="Register", bg="blue", fg="white", cursor="hand2",
               command=self.connect_database, width=10).place(x=200, y=340)

        self.lb6 = Label(self.master, text="Already a user?", width=45, bg="#909af5",
                         font=("arial", 10))
        self.lb6.place(x=19, y=400)
        self.en6 = Button(self.master, text="Log In", width=10, border=0, fg='blue', bg="#909af5",
                          cursor="hand2", font=("arial", 10, 'bold'), command=self.logIn_page)
        self.en6.place(x=250, y=397)

    def clear(self):
        self.en3.delete(0, END)
        self.en4.delete(0, END)
        self.en5.delete(0, END)

    def connect_database(self):
        if self.en3.get() == '' or self.en4.get() == '' or self.en5.get() == '':
            messagebox.showerror('Error', 'All Fields are required!!!')
        elif self.en4.get() != self.en5.get():
            messagebox.showerror('Error', 'Password not matched!!!')
        else:
            db_handler = DatabaseHandler()
            db_handler.initialize_database()

            if db_handler.check_username_existence(self.en3.get()):
                messagebox.showerror('Error', 'Username already exists!!!')
            else:
                db_handler.insert_user(self.en3.get(), self.en4.get())
                db_handler.close_connection()

                messagebox.showinfo('Success', 'Registration is successful.')
                self.clear()
                self.master.destroy()
                import LogIn

    def logIn_page(self):
        self.master.destroy()
        from LogIn import LogInForm


register = Tk()
# Creating an instant of RegistrationForm and passing register window.
registration_form = RegistrationForm(register)
register.mainloop()
