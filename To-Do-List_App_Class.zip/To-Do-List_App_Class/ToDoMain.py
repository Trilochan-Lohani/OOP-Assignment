from tkinter import *
from tkinter import messagebox, ttk
import pymysql


class Task:
    def __init__(self, title, task_type, description, priority):
        self.title = title
        self.task_type = task_type
        self.description = description
        self.priority = priority


class TaskManager:
    def __init__(self):
        self.current_task = None

    def add_task(self, title, task_type, description, priority):
        if title == '' or task_type == '' or description == '':
            messagebox.showerror('Message', "Task fields are empty!!")
        else:
            try:
                con = pymysql.connect(host='localhost', user='root', password='12345')
                mycursor = con.cursor()
                query = 'create database if not exists registration'
                mycursor.execute(query)
                query = 'use registration'
                mycursor.execute(query)

                query = "show tables like 'todolist'"
                mycursor.execute(query)
                result = mycursor.fetchone()

                if not result:
                    query = ('create table todolist(list_id int auto_increment primary key not null, '
                             'title varchar(100), type varchar(500),'
                             ' description varchar(50), Priority varchar(20))')
                    mycursor.execute(query)

                query = 'insert into todolist(title, type, description, Priority) values(%s,%s,%s,%s)'
                mycursor.execute(query, (title, task_type, description, priority))

                con.commit()
                con.close()
                messagebox.showinfo('Success', 'List added successfully')
                self.current_task = Task(title, task_type, description, priority)
                clear()
                display_list()
            except Exception as e:
                messagebox.showerror('Error', f'An error occurred: {str(e)}')

    def update_task(self, selected_items, new_title, new_type, new_description, new_priority):
        if not selected_items:
            messagebox.showwarning("Update", "Please select a task to update.")
            return

        if not new_title or not new_type or not new_description:
            messagebox.showerror('Message', "Task fields are empty!!")
            return

        decision = messagebox.askquestion("Update data?", 'Do you want to update '
                                                          'selected data?')
        if decision != "yes":
            return

        else:
            try:
                con = pymysql.connect(host='localhost', user='root', password='12345',
                                      database='registration')
                mycursor = con.cursor()

                query = ('UPDATE todolist SET title=%s, type=%s, description=%s, Priority=%s '
                         'WHERE list_id=%s')
                mycursor.execute(query, (new_title, new_type, new_description, new_priority,
                                         selected_items))

                con.commit()
                con.close()

                messagebox.showinfo("Success", "Data updated successfully")
                clear()
                display_list()

            except Exception as e:
                messagebox.showinfo("Error", f"An error occurred during operation: {str(e)}")

    def delete_task(self, selected_items):
        if not selected_items:
            messagebox.showwarning("Delete", "Please select a task to delete.")
            return

        decision = messagebox.askquestion("Delete data?",
                                          'Do you want to delete selected data?')
        if decision != "yes":
            return
        else:
            deletedata = str(trv_todolist.item(selected_items)['values'][0])
            try:
                con = pymysql.connect(host='localhost', user='root', password='12345',
                                      database='registration')
                mycursor = con.cursor()

                query = 'DELETE FROM todolist WHERE list_id = %s'
                mycursor.execute(query, (deletedata,))

                con.commit()
                con.close()

                messagebox.showinfo("Success", "Data deleted successfully")
                display_list()

            except Exception as e:
                messagebox.showinfo("Error", f"An error occurred during operation: {str(e)}")


# Function to clear entry widgets
def clear():
    entitle.delete(0, END)
    entype.delete(0, END)
    endiscription.delete(0, END)


# Function to display tasks in the Treeview
def display_list():
    con = pymysql.connect(host='localhost', user='root', password='12345', database='registration')
    mycursor = con.cursor()

    trv_todolist.delete(*trv_todolist.get_children())

    query = 'SELECT * FROM todolist'
    mycursor.execute(query)

    rows = mycursor.fetchall()

    for dt in rows:
        trv_todolist.insert("", 'end', iid=dt[0], values=(dt[0], dt[1], dt[2], dt[3], dt[4]))

    con.close()

    # Focus First row of treeview.
    first_item = trv_todolist.get_children()[0] if trv_todolist.get_children() else ''
    trv_todolist.focus(first_item)
    trv_todolist.selection_set(first_item)


# Function to handle the "Add" button
def save_list():
    task_manager.add_task(entitle.get(), entype.get(), endiscription.get(), cv.get())


# Function to handle the "Edit" button
def edit_list():
    selected_items = trv_todolist.selection()[0]
    if not selected_items:
        messagebox.showwarning("Edit", "Please select a task to edit.")
        return
    # Get the data of the selected row
    selected_data = trv_todolist.item(selected_items)['values']

    # Populate the Entry and OptionMenu widgets with the selected data
    entitle.delete(0, END)
    entitle.insert(0, selected_data[1])

    entype.delete(0, END)
    entype.insert(0, selected_data[2])

    endiscription.delete(0, END)
    endiscription.insert(0, selected_data[3])

    cv.set(selected_data[4])


# Function to handle the "Update" button
def update_list():
    selected_items = trv_todolist.selection()[0]
    task_manager.update_task(selected_items, entitle.get(), entype.get(), endiscription.get(), cv.get())


# Function to handle the "Delete" button

def delete_list():
    selected_items = trv_todolist.selection()[0]
    task_manager.delete_task(selected_items)


# Function to handle the "Sort by Topic" button
def sort_by_topic():
    sort_by_column("2")


# Function to handle the "Sort by Task" button
def sort_by_task():
    sort_by_column("3")


# Function to handel the "Sort by Due Date" button
def sort_by_dueDate():
    sort_by_column("4")


# Function to handle the "Sort by Priority" button
def sort_by_priority():
    sort_by_column("5")


# Function to sort the Treeview by a specific column
def sort_by_column(column):
    items = [(trv_todolist.set(child, column), child) for child in trv_todolist.get_children("")]
    items.sort()
    for index, (val, child) in enumerate(items):
        trv_todolist.move(child, '', index)


# Function to filter data from columns of database table.
def filter_list():
    con = pymysql.connect(host='localhost', user='root', password='12345', database='registration')
    mycursor = con.cursor()

    trv_todolist.delete(*trv_todolist.get_children())
    search = ensearch.get()
    query = ('SELECT * FROM todolist WHERE title LIKE %s OR type LIKE %s OR description'
             ' LIKE %s OR priority LIKE %s')
    mycursor.execute(query, (f'%{search}%', f'%{search}%', f'%{search}%', f'%{search}%',))

    rows = mycursor.fetchall()

    for dt in rows:
        trv_todolist.insert("", 'end', iid=dt[0], values=(dt[0], dt[1], dt[2], dt[3], dt[4]))

    con.close()


# Function to handle the "Log Out" button
def log_Out():
    ToDoMain.destroy()
    import LogIn


# Create an instance of TaskManager
task_manager = TaskManager()

# Creating To-Do list table using treeview
ToDoMain = Tk()
ToDoMain.geometry("650x570")
ToDoMain.resizable(False, False)
ToDoMain.title("To-Do List")
ToDoMain['bg'] = "#909af5"

lb1 = Label(ToDoMain, text="Task Management", width=40, bg="#909af5", font=("arial", 20, 'bold'))
lb1.place(x=0, y=20)

lbtitle = Label(ToDoMain, text="Topic", width=20, anchor="w", bg="#909af5", font=("arial", 12))
lbtitle.place(x=15, y=70)
entitle = Entry(ToDoMain)
entitle.place(x=150, y=70)

lbtype = Label(ToDoMain, text="Task Type", width=20, anchor="w", bg="#909af5", font=("arial", 12))
lbtype.place(x=300, y=70)
entype = Entry(ToDoMain)
entype.place(x=450, y=70)

lbdiscription = Label(ToDoMain, text="Due Date", width=20, anchor="w", bg="#909af5", font=("arial", 12))
lbdiscription.place(x=15, y=100)
lbdateformat = Label(ToDoMain, text="(dd/mm/yyyy)", width=20, anchor="w", bg="#909af5", font=("arial", 9))
lbdateformat.place(x=15, y=120)
endiscription = Entry(ToDoMain)
endiscription.place(x=150, y=100)

# Creating labels to set the status of task.
lbpriority = Label(ToDoMain, text="Priority", anchor="w", width=20, bg="#909af5", font=("arial", 12))
lbpriority.place(x=300, y=100)
priority_list = ("High", "Medium", "Low", "Completed")
cv = StringVar()
droplist = OptionMenu(ToDoMain, cv, *priority_list)
droplist.config(width=8)
cv.set("High")
droplist.place(x=450, y=100)

# Add button controls.
Button(ToDoMain, text="Add", bg="blue", fg="white", cursor="hand2", width=10, border=0,
       command=save_list, font=("arial", 10, 'bold')).place(x=100, y=150)

Button(ToDoMain, text="Edit", bg="blue", fg="white", cursor="hand2", width=10, border=0,
       command=edit_list, font=("arial", 10, 'bold')).place(x=200, y=150)

Button(ToDoMain, text="Update", bg="blue", fg="white", cursor="hand2", width=10, border=0,
       command=update_list, font=("arial", 10, 'bold')).place(x=300, y=150)

Button(ToDoMain, text="Delete", bg="blue", fg="white", cursor="hand2", width=10, border=0,
       command=delete_list, font=("arial", 10, 'bold')).place(x=400, y=150)

lbsortby = Label(ToDoMain, text="Sort by :", width=20, anchor="w", bg="#909af5", font=("arial", 12))
lbsortby.place(x=15, y=200)

Button(ToDoMain, text="Topic", bg="#805fb3", fg="white", cursor="hand2", width=10, border=0,
       command=sort_by_topic, font=("arial", 10, 'bold')).place(x=100, y=200)

Button(ToDoMain, text="Task", bg="#805fb3", fg="white", cursor="hand2", width=10, border=0,
       command=sort_by_task, font=("arial", 10, 'bold')).place(x=200, y=200)

Button(ToDoMain, text="Due Date", bg="#805fb3", fg="white", cursor="hand2", width=10, border=0,
       command=sort_by_dueDate, font=("arial", 10, 'bold')).place(x=300, y=200)

Button(ToDoMain, text="Priority", bg="#805fb3", fg="white", cursor="hand2", width=10,
       border=0, command=sort_by_priority, font=("arial", 10, 'bold')).place(x=400, y=200)

enLog_Out = Button(ToDoMain, text="Log Out", width=10, border=0, fg='white', bg="#1d1942", cursor="hand2",
                   font=("arial", 10, 'bold'), command=log_Out)
enLog_Out.place(x=565, y=0)

lbdiscription = Label(ToDoMain, text="Filter Your Task", width=20, anchor="w", bg="#909af5",
                      font=("arial", 12))
lbdiscription.place(x=150, y=250)
ensearch = Entry(ToDoMain)
ensearch.place(x=290, y=253)
Button(ToDoMain, text="Search", bg="#433c80", fg="white", cursor="hand2", width=10,
       border=0, command=filter_list, font=("arial", 10, 'bold')).place(x=400, y=250)

# Creating To-Do list table using treeview
trv_todolist = ttk.Treeview(ToDoMain, selectmode='browse')
trv_todolist.grid(row=1, column=1, padx=20, pady=20)
trv_todolist["columns"] = ("1", "2", "3", "4", "5")
trv_todolist["show"] = 'headings'
trv_todolist.column("1", width=30, anchor='w')
trv_todolist.column("2", width=70, anchor='w')
trv_todolist.column("3", width=320, anchor='w')
trv_todolist.column("4", width=90, anchor='w')
trv_todolist.column("5", width=70, anchor='w')
trv_todolist.heading("1", text="ID")
trv_todolist.heading("2", text="Topic")
trv_todolist.heading("3", text="Task")
trv_todolist.heading("4", text="Due Date")
trv_todolist.heading("5", text="Priority")
trv_todolist.place(x=30, y=300)

# Display Database table rows on page load.
display_list()

ToDoMain.mainloop()
