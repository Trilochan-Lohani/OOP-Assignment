from tkinter import *
from tkinter import messagebox
import pymysql


class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password


class UserManager:
    def __init__(self):
        self.current_user = None

    def login_user(self, username, password):
        if username == '' or password == '':
            messagebox.showerror('Error', 'Username/password are empty.')
        else:
            try:
                con = pymysql.connect(host='localhost', user='root', password='12345')
                mycursor = con.cursor()
            except:
                messagebox.showerror('Error', 'Connection not found, try again')
                return
            query = 'use registration'
            mycursor.execute(query)
            query = 'select * from student where username=%s and password=%s'
            mycursor.execute(query, (username, password))
            row = mycursor.fetchone()

            if row is None:
                messagebox.showerror('Error', 'Username/password mismatched!!!')
            else:
                self.current_user = User(username, password)
                logIn_Form.destroy()
                import ToDoMain


class LogInForm:
    def __init__(self, master):
        self.master = master
        self.master.geometry("500x500")
        self.master.resizable(False, False)
        self.master.title("Log In")
        self.master['bg'] = "#909af5"
        self.user_manager = UserManager()

        self.create_widgets()

    # Function to create Log In window.
    def create_widgets(self):
        self.lb1 = Label(self.master, text="To Do APP", width=10, bg="#909af5",
                         font=("arial", 20, 'bold'))
        self.lb1.place(x=170, y=30)

        self.lb2 = Label(self.master, text="Log In", width=10, bg="#909af5",
                         font=("arial", 16, 'bold'))
        self.lb2.place(x=190, y=100)

        self.lb3 = Label(self.master, text="User Name", width=20, bg="#909af5",
                         font=("arial", 12))
        self.lb3.place(x=19, y=200)
        self.en3 = Entry(self.master)
        self.en3.place(x=200, y=200)
        self.en3.focus()

        self.lb4 = Label(self.master, text="Password", width=20, bg="#909af5",
                         font=("arial", 12))
        self.lb4.place(x=19, y=250)
        self.en4 = Entry(self.master, show='*')
        self.en4.place(x=200, y=250)

        Button(self.master, text="Log In", bg="blue", fg="white", cursor="hand2", width=10,
               command=self.login_user).place(x=200, y=300)

        self.lb5 = Label(self.master, text="Not registered yet?", width=30, bg="#909af5",
                         font=("arial", 10))
        self.lb5.place(x=19, y=375)
        self.en5 = Button(self.master, text="Register Here", cursor="hand2", width=15, border=0, fg='blue',
                          bg="#909af5", font=("arial", 10, 'bold'),
                          command=self.register_page)
        self.en5.place(x=200, y=373)

    def login_user(self):
        self.user_manager.login_user(self.en3.get(), self.en4.get())

    def register_page(self):
        self.master.destroy()
        from Register import RegistrationForm


logIn_Form = Tk()
# Creating an instant of LogInForm and passing logIn_Form window.
log_in_form = LogInForm(logIn_Form)
logIn_Form.mainloop()
